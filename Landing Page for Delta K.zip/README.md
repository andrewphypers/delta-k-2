
  # Landing Page for Delta K

  This is a code bundle for Landing Page for Delta K. The original project is available at https://www.figma.com/design/WIsSGshefwvgEvX4EBg9l5/Landing-Page-for-Delta-K.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  